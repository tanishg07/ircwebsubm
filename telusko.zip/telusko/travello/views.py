from django.shortcuts import render
from sympy import re
# Create your views here.
from .models import Destination

def index(request):
    dests=Destination.objects.all()
    return render(request, "index.html")
def about(request):
    return render(request,"about.html")
def contact(request):
    return render(request,"contact.html")
def portfolio(request):
    return render(request,"portfolio.html")

def service(request):
    return render(request,"service.html")