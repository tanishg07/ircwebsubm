from django.db import models

# Create your models here.


class Destination(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    idname=models.CharField(max_length=100)
    rooms=models.IntegerField()
