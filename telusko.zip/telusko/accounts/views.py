from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth   
from django.contrib import messages
# Create your views here.
def login(request):
    if request.method=='POST':
        idname=request.POST['uniqueid']
        user=auth.authenticate(username=idname)
        if user is not None:    
            auth.login(request,user)
            return redirect("/")
        else:
            messages.info(request,'no order found')
            return redirect('login')
    else:
        return render(request,'login.html')
def register(request):
    if request.method=='POST':
        last_name=request.POST['name']
        mail=request.POST['mail']
        idname=request.POST['uniqueid']       
        rooms=request.POST['rooms']
        if User.objects.filter(username=idname).exists():
            messages.info(request,'order exists')
            return redirect('register')
        else:
            user=User.objects.create_user(last_name=last_name,email=mail,username=idname,password=rooms)
            user.save();
            messages.info(request,'user created ')
            return redirect('login')
        return redirect('/')
    else:
        return render(request,'register.html')